package TestNG.Demo;

import org.testng.annotations.Test;

public class ClassOne {

    @Test
    public void ClassOneTest1(){
        System.out.println("ClassOneTest1");
    }

    @Test (enabled = false)
    public void ClassOneTest2(){
        System.out.println("ClassOneTest2");
    }

    @Test
    public void ClassOneTest3(){
        System.out.println("ClassOneTest3");
    }
}
